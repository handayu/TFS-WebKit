// JSCore.h

#pragma once

using namespace System;

namespace WebKit {
namespace JSCore {

    

}}
